//
//  VanillaTableViewController.swift
//  Ice Cream Villa
//
//  Created by Muhammad  Hammad  on 12/06/2020.
//  Copyright © 2020 Muhammad  Hammad . All rights reserved.
//

import UIKit

import Foundation
import  CoreFoundation

class VanillaTableViewController: UITableViewController {

    @IBOutlet weak var itemImage1: UIImageView!
    @IBOutlet weak var itemName1: UILabel!
    
    @IBOutlet weak var itemImage2: UIImageView!
    @IBOutlet weak var itemName2: UILabel!
    
    @IBOutlet weak var itemImage3: UIImageView!
    @IBOutlet weak var itemName3: UILabel!
    
    @IBOutlet weak var itemImage4: UIImageView!
    @IBOutlet weak var itemName4: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }

    @IBAction func cancelButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    // MARK: - Table view data source

    
    @IBAction func orderButton(_ sender: Any) {
    }
    
    
    
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 4
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    
         if segue.identifier == "item1" {
         let VC = segue.destination as! VanillaOrderViewController
         VC.NameItem = itemName1.text!
         VC.ImagItem = itemImage1.image!
        } else  if segue.identifier == "item2" {
               let VC = segue.destination as! VanillaOrderViewController
               VC.NameItem = itemName2.text!
               VC.ImagItem = itemImage2.image!
         }else  if segue.identifier == "item3" {
               let VC = segue.destination as! VanillaOrderViewController
               VC.NameItem = itemName3.text!
               VC.ImagItem = itemImage3.image!
         }else  if segue.identifier == "item4" {
               let VC = segue.destination as! VanillaOrderViewController
               VC.NameItem = itemName4.text!
               VC.ImagItem = itemImage4.image!
         }
    }
}
