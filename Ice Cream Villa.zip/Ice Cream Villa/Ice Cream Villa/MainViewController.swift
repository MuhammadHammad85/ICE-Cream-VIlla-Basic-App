//
//  MainViewController.swift
//  Ice Cream Villa
//
//  Created by Muhammad  Hammad  on 10/06/2020.
//  Copyright © 2020 Muhammad  Hammad . All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    @IBOutlet weak var gifImage: UIImageView!
    @IBOutlet weak var ChocolateButton: UIButton!
    @IBOutlet weak var strawberryButton: UIButton!
    @IBOutlet weak var butterPecanButton: UIButton!
    @IBOutlet weak var VanillaButton: UIButton!
    
    var userName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        gifImage.loadGif(name: "main")
        ChocolateButton.layer.cornerRadius = 20
        strawberryButton.layer.cornerRadius = 20
        butterPecanButton.layer.cornerRadius = 20
        VanillaButton.layer.cornerRadius = 20
    }
   
    
    @IBAction func menuButton(_ sender: Any) {
        
        performSegue(withIdentifier: "menuSegue", sender: self)
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "menuSegue"{
        let mainVC = segue.destination as! MenuViewController
            mainVC.userName = self.userName
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
