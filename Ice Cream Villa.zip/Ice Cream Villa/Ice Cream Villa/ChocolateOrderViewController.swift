//
//  ChocolateOrderViewController.swift
//  Ice Cream Villa
//
//  Created by Muhammad  Hammad  on 19/06/2020.
//  Copyright © 2020 Muhammad  Hammad . All rights reserved.
//

import UIKit
import Foundation

class ChocolateOrderViewController: UIViewController {

    
    @IBOutlet weak var CounterLabel: UILabel!
    @IBOutlet weak var addresTextview: UITextView!
    @IBOutlet weak var stepperValue: UIStepper!
  
    @IBOutlet weak var itemImage: UIImageView!
    @IBOutlet weak var itemName: UILabel!
  
    var NameItem = String()
      var ImagItem = UIImage()

   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       itemName.text = NameItem
       itemImage.image = ImagItem
    }
    
    
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func cancelButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
 
    
    @IBAction func StepperCounter(_ sender: UIStepper) {
            
        CounterLabel.text = "\(Int(stepperValue.value))"
        
    }
    @IBAction func OrderButton(_ sender: Any) {
        if addresTextview.text == "" {
                   let message = "Address Required"

                   let title = "Message"
                      let alert = UIAlertController(title: title , message: message , preferredStyle: .alert)
                      
                      let action = UIAlertAction(title: "OK", style: .default, handler: nil )
                   
                      alert.addAction(action)
                      
                      present(alert, animated: true, completion: nil)
               }else{
    let message = "Your Order Has Been Confirmed"
            let title = "Confirmation Message"
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert
            )
            
            let action = UIAlertAction(title: "OK", style: .default, handler: {
                action in self.cancelButton((Any).self)
            })
             
            
            alert.addAction(action)
            present(alert, animated: true, completion: nil )
            
           
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
