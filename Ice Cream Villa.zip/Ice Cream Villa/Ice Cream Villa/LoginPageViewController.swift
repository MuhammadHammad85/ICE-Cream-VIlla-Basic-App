//
//  ViewController.swift
//  Ice Cream Villa
//
//  Created by Muhammad  Hammad  on 10/06/2020.
//  Copyright © 2020 Muhammad  Hammad . All rights reserved.
//

import UIKit

class LoginPageViewController: UIViewController {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var userNameTextField: UITextField!

    var userName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        backgroundImage.loadGif(name: "login page gif")
        loginButton.layer.cornerRadius = 20
    }
    

    @IBAction func logInButton(_ sender: Any) {
        if userNameTextField.text == "" {
            let message = "Required Username"
            let title = "Message"
               let alert = UIAlertController(title: title , message: message , preferredStyle: .alert)
               
               let action = UIAlertAction(title: "OK", style: .default, handler: nil )
            
               alert.addAction(action)
               
               present(alert, animated: true, completion: nil)
        }else{
            self.userName = userNameTextField.text!
            performSegue(withIdentifier: "loginScreenSegue", sender: self)
           
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let loginPageVC = segue.destination as! MainViewController
        loginPageVC.userName = self.userName
        
    }
}

