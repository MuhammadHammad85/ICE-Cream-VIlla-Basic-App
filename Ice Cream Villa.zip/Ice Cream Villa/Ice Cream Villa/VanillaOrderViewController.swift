//
//  VanillaOrderViewController.swift
//  Ice Cream Villa
//
//  Created by Muhammad  Hammad  on 20/06/2020.
//  Copyright © 2020 Muhammad  Hammad . All rights reserved.
//
import UIKit
import Foundation

class VanillaOrderViewController: UIViewController {
    
    @IBOutlet weak var itemImage: UIImageView!
       @IBOutlet weak var itemName: UILabel!
       @IBOutlet weak var CounterLabel: UILabel!
       @IBOutlet weak var addressTextview: UITextView!
       @IBOutlet weak var stepperValue: UIStepper!
  
    var NameItem = String()
      var ImagItem = UIImage()

   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       itemName.text = NameItem
       itemImage.image = ImagItem
    }
    
    
    @IBAction func back(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func cancelButton(_ sender: Any) {
         dismiss(animated: true, completion: nil)
    }
    
    
   
      @IBAction func StepperCounter(_ sender: UIStepper) {
              CounterLabel.text = "\(Int(stepperValue.value))"
      }
      
      
      @IBAction func OrderButton(_ sender: Any) {
          if addressTextview.text == "" {
              let message = "Address Required"
              let title = "Message"
              let alert = UIAlertController(title: title , message: message , preferredStyle: .alert)
           
              let action = UIAlertAction(title: "OK", style: .default, handler: nil )
           
              alert.addAction(action)
           
              present(alert, animated: true, completion: nil)
           } else{
             let message = "Your Order Has Been Confirmed"
             let title = "Confirmation Message"
             let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
           
             let action = UIAlertAction(title: "OK", style: .default, handler: {
             action in self.cancelButton((Any).self)
             })
           
           alert.addAction(action)
           present(alert, animated: true, completion: nil )
           
           
          }
      }
      
    
}
